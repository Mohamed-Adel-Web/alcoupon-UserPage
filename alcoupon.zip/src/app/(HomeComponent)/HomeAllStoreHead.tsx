import { Box, Typography } from "@mui/material";
import Link from "next/link";
import { CountryData } from "../StoreData";

function HomeAllStoreHead() {
  return (
    <Box>
      <Typography variant="h6" sx={{ padding: "1rem 0" }}>
        Offers for Featured Stores in {CountryData.countryName}
        <Link
          href={"/hot-discount-coupons-deals"}
          style={{
            textDecoration: "none",
            color: "#0558A0",
            marginLeft: "1rem",
            display: "inline-block",
          }}>
          See all offers
        </Link>
      </Typography>
    </Box>
  );
}
export default HomeAllStoreHead;
