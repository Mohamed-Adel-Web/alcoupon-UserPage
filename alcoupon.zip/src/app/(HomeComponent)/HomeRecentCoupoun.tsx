import { Box, Tooltip, Typography } from "@mui/material";
import { CouponDate } from "../StoreData";
import { CountryData, TopStoresData } from "../StoreData";
import Grid from "@mui/material/Unstable_Grid2";
import Link from "next/link";
const secondaryHeadStyle = {
  width: "fit-content",
  fontSize: "0.8rem",
  fontWeight: "bold",
};

const storeBoxStyle = { margin: "1rem 0" };

const storeList = TopStoresData.map((store) => {
  return (
    <Box sx={storeBoxStyle}>
      <Tooltip title={store.imageTitle}>
        <Link
          href={store.imageHref}
          style={{
            fontSize: "14px",
            margin: "0.3rem 0",
            textDecoration: "none",
            color: "#0558A0",
          }}>
          {store.storeName}
        </Link>
      </Tooltip>
    </Box>
  );
});
const CouponCodeList = TopStoresData.map((store) => {
  return (
    <Box sx={storeBoxStyle}>
      {" "}
      <Tooltip title={"Coupon code"}>
        <Typography
          variant="body2"
          color="text.secondary"
          sx={{ width: "fit-content" }}>
          {store.couponCode[0]}
        </Typography>
      </Tooltip>
    </Box>
  );
});
const discountDetailsList = TopStoresData.map((store) => {
  return (
    <Box sx={storeBoxStyle}>
      <Tooltip
        title={`${CountryData.countryName} Discounts, Coupons & Promo Codes ${CouponDate.month}`}>
        <Link
          href={store.imageHref}
          style={{
            fontSize: "14px",
            textDecoration: "none",
            color: "#0558A0",
          }}>
          {store.couponDiscountTitle[0]}
        </Link>
      </Tooltip>
    </Box>
  );
});

function HomeRecentCoupon() {
  const countryCities = CountryData.countryCities?.map(
    (city, i) => `${city}, `
  );
  return (
    <Box
      sx={{
        backgroundColor: "white",
        padding: "1rem 2rem",
        margin: "2rem 0",
        border: "1px solid #dddddd",
      }}>
      <Typography variant="h6">
        {CountryData.countryName} Discounts, Coupons & Promo Codes {CouponDate.month}{" "}
        {CouponDate .year}
      </Typography>
      <Grid container spacing={2} sx={{ padding: "1rem 0" }}>
        <Grid xs={2}>
          <Tooltip
            title={`${CountryData.countryName} Discounts, Coupons & Promo Codes March 2024`}>
            <Typography sx={secondaryHeadStyle}>Online store</Typography>
          </Tooltip>
          {storeList}
        </Grid>
        <Grid xs={2}>
          <Tooltip
            title={`${CountryData.countryName} Discounts, Coupons & Promo Codes March 2024`}>
            <Typography sx={secondaryHeadStyle}>Coupon code</Typography>
          </Tooltip>
          {CouponCodeList}
        </Grid>
        <Grid xs={8}>
          <Tooltip
            title={`${CountryData.countryName} Discounts, Coupons & Promo Codes March 2024`}>
            <Typography sx={secondaryHeadStyle}>Discount details</Typography>
          </Tooltip>
          {discountDetailsList}
        </Grid>
      </Grid>
      <Typography variant="body2" color="text.secondary">
        All the promo codes and coupons listed are valid through March 2024. Get
        the lowest prices of the season with our exclusive discounts in all
        online shops shipping to all cities in {CountryData.countryName}{" "}
        including {countryCities}
        ... etc.:
      </Typography>
      <Typography
        variant="body2"
        color="text.secondary"
        sx={{ margin: "1rem 0" }}>
        <Link
          style={{ textDecoration: "none", color: "#0558A0" }}
          href={"/discount-codes"}>
          see all offers{" "}
        </Link>
      </Typography>
    </Box>
  );
}
export default HomeRecentCoupon;
