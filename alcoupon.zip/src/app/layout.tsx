import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Container from "@mui/material/Container";
import Footer from "./Footer/Footer";
import NavBar from "./(Header)/NavBar";
import NavigationLinks from "./(Header)/NavigationLinks";
const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: {
    default: "Al Coupon - Egypt Online Stores Discount Codes",
    template: "%s | Al Coupon - Egypt Online Stores Discount Codes",
  },
  description:
    "Searching for the best coupon codes for Arab & international online stores? Al Coupon offers you the latest promo codes & discounts, valid in Egypt",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head> <link rel="shortcut icon" type="image/png" href="/images/title/favicon.ico" /></head>
      <body className={inter.className}>
        <NavBar />
        <NavigationLinks />
        <Container
          maxWidth="lg"
          sx={{ textAlign: { xs: "center", md: "left" } }}>
          {children}
        </Container>
        <footer>
          <Footer />
        </footer>
      </body>
    </html>
  );
}
