export interface StoresDataType {
  imageSrc: string;
  imageTitle: string;
  imageHref: string;
  couponCode: string[];
  couponDiscount: string[];
  couponDiscountTitle: string[];
  storeDiscount: string;
  storeName: string;
  catagories: string[];
  feature: string;
  storeSiteLink: string;
}
export const StoresData: StoresDataType[] = [
  {
    imageSrc: "/images/TopStore/store3.png",
    imageTitle: "Noon Egypt store's Coupons and Promo Codes",
    imageHref: `/discount-codes/`,
    couponCode: ["ALb", "ALC"],
    couponDiscount: ["11% Discount (up to 50 EGP OFF"],
    couponDiscountTitle: [
      "102% Noon Egypt coupon code 2024 (up to 50 EGP for new users)",
    ],
    storeDiscount: "5% - 10% Exclusive Coupon",
    storeName: "Noon",
    catagories: ["fashion", "beauty"],
    feature: "Top Store",
    storeSiteLink: "https://www.noon.com/egypt-en/",
  },
  {
    imageSrc: "/images/TopStore/store3.png",
    imageTitle: "Noon Egypt store's Coupons and Promo Codes",
    imageHref: "/discount-codes/",
    couponCode: ["ALC"],
    couponDiscount: [
      "10% Discount (up to 50 EGP OFF",
      "10% Discount (up to 50 EGP OFF",
    ],
    couponDiscountTitle: [
      "10% Noon Egypt coupon code 2024 (up to 50 EGP for new users)",
    ],
    storeDiscount: "5% - 10% Exclusive Coupon",
    storeName: "Noon",
    catagories: ["fashion", "beauty"],
    feature: "Top Store",
    storeSiteLink: "https://www.noon.com/egypt-en/",
  },
  {
    imageSrc: "/images/TopStore/store3.png",
    imageTitle: "Noon Egypt store's Coupons and Promo Codes",
    imageHref: "/discount-codes/",
    couponCode: ["ALC"],
    couponDiscount: ["10% Discount (up to 50 EGP OFF"],
    couponDiscountTitle: [
      "10% Noon Egypt coupon code 2024 (up to 50 EGP for new users)",
    ],
    storeDiscount: "5% - 10% Exclusive Coupon",
    storeName: "Noon",
    catagories: ["fashion", "beauty"],
    feature: "Top Store",
    storeSiteLink: "https://www.noon.com/egypt-en/",
  },
];
export const TopStoresData: StoresDataType[] = StoresData.filter((store) => {
  return store.feature === "Top Store";
})!;
export interface CountryDataType {
  countryName: string;
  countryCities: string[];
  countryCurrency: string;
}
export const CountryData: CountryDataType = {
  countryName: "Egypt",
  countryCities: ["Cairo", "Alexandria", "Giza"],
  countryCurrency: "Egyptian Pound",
};
export interface DateType {
  month: string;
  year: string;
}
const months: string[] = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

export const CouponDate: DateType = {
  month: `${months[new Date().getMonth()]}`,
  year: `${new Date().getFullYear()}`,
};
