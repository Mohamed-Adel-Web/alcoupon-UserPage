import { Box, Button, Container, Typography } from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import Link from "next/link";
import { CountryData, CouponDate } from "../StoreData";
import "./Footer.css";
import InstagramIcon from "@mui/icons-material/Instagram";
import TwitterIcon from "@mui/icons-material/Twitter";
import FacebookIcon from "@mui/icons-material/Facebook";
import TelegramIcon from "@mui/icons-material/Telegram";
import AndroidIcon from "@mui/icons-material/Android";
import AppleIcon from "@mui/icons-material/Apple";
import Image from "next/image";
const countries: string[] = [
  "Saudi Arabia",
  "UAE",
  "Kuwait",
  "Bahrain",
  "Oman",
  "Qatar",
  "Egypt",
  "Jordan",
  "Morocco",
];
const countryList = countries.map((country) => {
  return (
    <li style={{ margin: "0.7rem 0" }}>
      <Link href={"/"} style={{ textDecoration: "none", color: "#0558A0" }}>
        {country}
      </Link>
    </li>
  );
});
const featureSection: string[] = [
  ` Stores in ${CountryData.countryName}  `,
  ` Special ${CountryData.countryName} deals `,
  `Shopping Blog in ${CountryData.countryName}`,
  `Al Coupon Sitemap `,
  `About Alcoupon in ${CountryData.countryName}`,
  ` How to use the discount coupon?`,
  ` Trendyol discount code `,
  ` Noon Coupon code `,
  ` Product reviews in ${CountryData.countryName} `,
  ` Sporter coupon `,
  ` Nice One Coupon in ${CountryData.countryName} `,
  ` Single's Day Offers `,
  ` Black Friday Sale `,
  ` White Friday Sale `,
  ` Noon Yellow Friday Sale `,
  ` Download Coupons Mobile App `,
  ` Privacy policy `,
];
const featureSectionList = featureSection.map((section) => {
  return (
    <li style={{ margin: "0.7rem 0" }}>
      <Link href={"/"} style={{ textDecoration: "none", color: "#0558A0" }}>
        {section}
      </Link>
    </li>
  );
});
const footerTopStore: string[] = [
  `Noon ${CountryData.countryName} store's Coupons and Promo Codes`,
  `Aliexpress Promo Codes, Coupon Codes & Discounts ${CountryData.countryName}`,
  `Amazon ${CountryData.countryName} Coupon Codes, Deals ${CouponDate.year}
`,
  `Farfetch Promo Codes and Latest Discount Code ${CouponDate.year}`,
  `Trendyol discount code ${CountryData.countryName} | Up to 50% OFF`,
  `Latest Namshi Coupon Codes & Discounts ${CouponDate.year}`,
  `Asos | Best Asos discount codes and offers ${CountryData.countryName}
`,
  `Latest Shein Discount Code & Coupons ${CouponDate.year}`,
];
const TopFooterList = footerTopStore.map((store) => {
  return (
    <li style={{ margin: "0.7rem 0" }}>
      <Link href={"/"} style={{ textDecoration: "none", color: "#0558A0" }}>
        {store}
      </Link>
    </li>
  );
});
function Footer() {
  return (
    <Box
      sx={{
        backgroundColor: "white",
        padding: "2rem 0rem",
        border: "1px solid #dddddd",
        marginTop: "2rem",
        textAlign: { xs: "center", md: "left" },
      }}>
      <Container maxWidth="lg">
        <Grid container spacing={2}>
          <Grid xs={12} md={6} lg={2}>
            <Typography sx={{ fontWeight: "bold" }}>Changes Country</Typography>
            <ul>{countryList}</ul>
          </Grid>
          <Grid xs={12} md={6} lg={3}>
            <Typography sx={{ fontWeight: "bold" }}>
              Featured sections
            </Typography>
            <ul>{featureSectionList}</ul>
          </Grid>
          <Grid xs={12} md={6} lg={5}>
            <Typography sx={{ fontWeight: "bold" }}>
              Popular stores in {CountryData.countryName}
            </Typography>
            <ul>{TopFooterList}</ul>
          </Grid>
          <Grid xs={12} md={6} lg={2} sx={{ textAlign: "center" }}>
            <Typography
              variant="h6"
              noWrap
              component="a"
              sx={{
                mr: 2,
                display: "flex",
                fontFamily: "monospace",
                fontWeight: 700,
                letterSpacing: ".3rem",
                color: "inherit",
                textDecoration: "none",
                justifyContent: "center",
              }}>
              <Image
                src="https://d318j52nj6xnxf.cloudfront.net/sites/all/themes/alcoupon/svg/logo.svg"
                width={141}
                height={41}
                alt="Picture of the author"
              />{" "}
            </Typography>
            <Typography sx={{ fontWeight: "bold", margin: "1rem 0 " }}>
              Follow us
            </Typography>
            <ul
              style={{
                display: "flex",
                justifyContent: "space-around",
                flexWrap: "wrap",
                gap: "1.5rem",
              }}
              className="icons">
              <li>
                <Link
                  href={"/"}
                  style={{
                    textDecoration: "none",
                    color: "red",
                  }}
                  className="icon-href">
                  <InstagramIcon sx={{ fontSize: "2rem" }} />
                </Link>
              </li>
              <li>
                <Link
                  href={"/"}
                  style={{ textDecoration: "none", color: "red" }}
                  className="icon-href">
                  <TwitterIcon sx={{ fontSize: "2rem" }} />
                </Link>
              </li>
              <li>
                <Link
                  href={"/"}
                  style={{ textDecoration: "none", color: "red" }}
                  className="icon-href">
                  <FacebookIcon sx={{ fontSize: "2rem" }} />
                </Link>
              </li>
              <li>
                <Link
                  href={"/"}
                  style={{ textDecoration: "none", color: "red" }}
                  className="icon-href">
                  <TelegramIcon sx={{ fontSize: "2rem" }} />
                </Link>
              </li>
            </ul>
            <Typography sx={{ fontWeight: "bold", margin: "1rem 0 " }}>
              Alcoupon App
            </Typography>
            <Link
              href={"/"}
              style={{
                textDecoration: "none",
                background: "brown",
                padding: "0.5rem 1rem ",
                color: "white",
                borderRadius: "2rem",
              }}>
              App download link
            </Link>
            <Typography
              style={{
                display: "flex",
                alignItems: "center",
                margin: "1rem 0",
                justifyContent: "center",
              }}>
              Available for
              <Link
                href={"/"}
                style={{
                  margin: "0 0.5rem",
                  textDecoration: "none",
                  color: "#0558A0",
                }}>
                <AndroidIcon sx={{ fontSize: "2rem" }} />
              </Link>
              <Link
                href={"/"}
                style={{ textDecoration: "none", color: "#0558A0" }}>
                <AppleIcon sx={{ fontSize: "2rem" }} />
              </Link>
            </Typography>
            <Box sx={{ margin: "1rem 0" }}>
              <Typography sx={{ fontWeight: "bold" }}>
                Address in Egypt
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Giza - Cairo, Egypt egypt@alcoupon.com{" "}
              </Typography>
            </Box>
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{ border: "1px solid #dddddd", padding: "0.3rem" }}>
              DISCLOSURE: Some Ads are paid and we may earn commissions from
              using links and coupons in this website.{" "}
            </Typography>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
}
export default Footer;
