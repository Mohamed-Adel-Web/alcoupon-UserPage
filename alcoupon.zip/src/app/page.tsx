import styles from "./page.module.css";
import HeroSection from "./(HeroSection)/HeroSection";
import HotOffersHead from "./(HomeComponent)/HotOffersHead";
import HotOffersMain from "./(HomeComponent)/HotOffersMain";
import HomeDiscountAd from "./(HomeComponent)/HomeDiscountAd";
import HomeAllStore from "./(HomeComponent)/HomeAllStoreHead";
import HomeAllStoreMain from "./(HomeComponent)/HomaAllStoreMain";
import HomeRecentCoupon from "./(HomeComponent)/HomeRecentCoupoun";
import CouponInstruction from "./(HomeComponent)/CouponInstruction";

export default function Home() {
  return (
    <main className={styles.main}>
      <HeroSection />
      <HotOffersHead />
      <HotOffersMain />
      <HomeDiscountAd />
      <HomeAllStore />
      <HomeAllStoreMain />
      <HomeRecentCoupon />
      <CouponInstruction  />
    </main>
  );
}
