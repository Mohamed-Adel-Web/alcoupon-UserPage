import { Box, Button, Tooltip, Typography } from "@mui/material";
import Link from "next/link";
import Grid from "@mui/material/Unstable_Grid2";
import LocalFireDepartmentIcon from "@mui/icons-material/LocalFireDepartment";
import { StoresData } from "@/app/StoreData";
import CouponHead from "./CouponHead";
import CouponRight from "./CouponRight";
import TelegramIcon from "@mui/icons-material/Telegram";
import CouponDetails from "./CouponDetails";
export default function couponDetails({
  params,
}: {
  params: { couponName: string };
}) {
  return (
    <Box sx={{ padding: "1rem 0" }}>
      <Grid container spacing={2}>
        <Grid lg={8} xs={12}>
          <CouponHead couponName={params.couponName} />
          {/* couponDetails */}
          <Box
            sx={{
              backgroundColor: "white",
              border: "1px solid #dddddd",
              overflow: "hidden",
            }}
          >
            <Grid container spacing={2}>
              <Grid
                lg={2}
                xs={12}
                sx={{
                  border: "1px solid #dddddd",
                  padding: "1rem 1.5rem",
                  display: "flex",
                  alignItems: "center",
                  textAlign: "center",
                  flexDirection: { lg: "column", xs: "row" },
                  justifyContent: "space-between",
                }}
              >
                {StoresData[0].couponDiscount}
                <Typography sx={{ color: "#B53D3D" }}>Coupon</Typography>
              </Grid>
              <Grid lg={10} xs={12} sx={{ padding: "1rem 1.5rem" }}>
                <Typography
                  variant="h5"
                  sx={{ fontSize: "1.3125rem", marginBottom: "1rem" }}
                >
                  {StoresData[0].couponDiscountTitle}
                </Typography>
                <Box>
                  <Grid container spacing={2}>
                    <Grid
                      xs={12}
                      lg={6}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: { xs: "center", lg: "left" },
                      }}
                    >
                      <LocalFireDepartmentIcon sx={{ marginRight: "0.5rem" }} />{" "}
                      Hot Deals
                    </Grid>
                    <Grid xs={12} lg={6}>
                      <CouponDetails />
                      <Link
                        href={StoresData[0].storeSiteLink}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          margin: "1rem 0",
                          textDecoration: "none",
                          color: "#0558A0",
                          fontSize: "14px",
                        }}
                      >
                        Go to {StoresData[0].storeName} website <TelegramIcon />
                      </Link>
                    </Grid>
                  </Grid>
                </Box>
              </Grid>
            </Grid>
          </Box>
          {/* couponDetails */}
        </Grid>
        <Grid lg={4} xs={12}>
          <CouponRight />
        </Grid>
      </Grid>
    </Box>
  );
}
