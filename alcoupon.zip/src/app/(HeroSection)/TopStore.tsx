import { Box, Tooltip } from "@mui/material";
import Link from "next/link";
import Grid from "@mui/material/Unstable_Grid2";
import Image from "next/image";
import { TopStoresData } from "../StoreData";
const TopHeroStore = TopStoresData.filter((store, index) => {
  return index < 6;
});
const TopStoreDataList = TopHeroStore.map((store) => {
  return (
    <Grid
      xs={6}
      md={4}
      lg={12}
      sx={{
        background: "white",
        textAlign: "center ",
        border: "1px solid #dddddd",
        padding: "0.45rem 2rem",
      }}>
      <Link href={`${store.imageHref + store.storeName}`}>
        <Tooltip
          title={store.imageTitle}
          sx={{ display: "block", widthL: "100%" }}>
          <Image
            width={100}
            height={100}
            style={{ height: "35px" }}
            src={store.imageSrc}
            alt="store image"
          />
        </Tooltip>
      </Link>
    </Grid>
  );
});
function TopStoreCoupon() {
  return (
    <Grid container spacing={0}>
      {TopStoreDataList}
    </Grid>
  );
}
export default TopStoreCoupon;
