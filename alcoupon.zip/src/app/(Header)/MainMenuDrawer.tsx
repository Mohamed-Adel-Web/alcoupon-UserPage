"use client";
import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import { Tooltip, Typography } from "@mui/material";
import Image from "next/image";
import Link from "next/link";
import { NavigationSources } from "./NavigationLinks";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
type Props = {
  open: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
};
const mainMenuNavigationSources: { title: string; href: string }[] = [
  ...NavigationSources,
  { title: "Alcoupon App", href: "/coupons-app" },
  {
    title: "Alcoupon App for Andriod",
    href: "https://play.google.com/store/apps/details?hl=en&id=com.alcoupon.apps&utm_source=website&utm_medium=buttons&utm_campaign=website_app_page1&ct=website_app_page1&utm_id=website_app_page1&referrer=hl%3Den%26id%3Dcom.alcoupon.apps%26utm_source%3Dwebsite%26utm_medium%3Dbuttons%26utm_campaign%3Dwebsite_app_page1%26ct%3Dwebsite_app_page1%26utm_id%3Dwebsite_app_page1%26referrer%3Dutm_source%253Dwebsite%2526utm_medium%253Dbuttons%2526utm_campaign%253Dwebsite_app_page1%2526ct%253Dwebsite_app_page1%2526utm_id%253Dwebsite_app_page1",
  },
  {
    title: "Alcoupon App for Iphone",
    href: "https://dl.getalcoupon.com/ar?efr=1&mt=8&pt=122685685&utm_source=website&utm_medium=buttons_pagelink&utm_campaign=website_app_page1&ct=website_app_page1&utm_id=website_app_page1&referrer=utm_source%3Dwebsite%26utm_medium%3Dbuttons%26utm_campaign%3Dwebsite_app_page1%26ct%3Dwebsite_app_page1%26utm_id%3Dwebsite_app_page1",
  },
];
const mainMenuNavigationLinks = (
  <Box sx={{ width: { xs: "100vw", md: "17vw" } }} role="presentation">
    <List>
      {mainMenuNavigationSources.map((link, index) => (
        <Link
          href={`${link.href}`}
          style={{ textDecoration: "none", color: "#000" }}>
          <ListItem key={index} disablePadding>
            <ListItemButton>
              <ListItemText primary={link.title} />
            </ListItemButton>
          </ListItem>
        </Link>
      ))}
    </List>
  </Box>
);
function MainMenuDrawer({ open, setOpen }: Props) {
  function handleDrawerClose() {
    setOpen(false);
  }

  return (
    <div>
      <Drawer open={open} onClose={handleDrawerClose}>
        <Box
          className={"DrawerHeader"}
          sx={{
            padding: "1rem 0.5rem",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}>
          <Typography
            sx={{
              mr: 2,
              display: "flex",
              fontFamily: "monospace",
              fontWeight: 700,
              letterSpacing: ".3rem",
              color: "inherit",
              textDecoration: "none",
            }}>
            <Image
              src="https://d318j52nj6xnxf.cloudfront.net/sites/all/themes/alcoupon/svg/logo-inverse.svg"
              width={120}
              height={41}
              alt="logo"
            />{" "}
          </Typography>
          <Tooltip
            title="Close"
            sx={{ color: "#fff", cursor: "pointer" }}
            onClick={handleDrawerClose}>
            <CloseRoundedIcon />
          </Tooltip>
        </Box>

        {mainMenuNavigationLinks}
      </Drawer>
    </div>
  );
}
export default MainMenuDrawer;

