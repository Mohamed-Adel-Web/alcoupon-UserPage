import Container from "@mui/material/Container";
import Link from "next/link";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Tooltip from "@mui/material/Tooltip";
import AndroidIcon from "@mui/icons-material/Android";
import AppleIcon from "@mui/icons-material/Apple";
export const NavigationSources: { title: string; href: string }[] = [
  { title: "Home", href: "/" },
  { title: "All Stores", href: "/discount-codes" },
  {
    title: "Ramadan Offers",
    href: "/ramadan-offers-country-best-products-cheap-prices",
  },
  {
    title: "Offers",
    href: "/hot-discount-coupons-deals",
  },
  {
    title: "Reviews",
    href: "reviews",
  },
  { title: "Beauty", href: "/shopping-category/beauty-products" },
  { title: "Fashion", href: "/shopping-category/fashion" },
  { title: "Mother & Baby", href: "/shopping-category/mother-and-baby" },
];
export const NavigationLinksList = NavigationSources.map((link) => {
  return (
    <Link
      href={`${link.href}`}
      style={{
        padding: "0 0.4rem",
        textDecoration: "none",
        color: "black",
        fontWeight: "400",
        fontSize: "0.875rem",
        lineHeight: "44px",
        letterSpacing: "2px",
        whiteSpace: "nowrap"
      }}>
      {link.title}
    </Link>
  );
});

function NavigationLinks() {
  return (
    <Box sx={{ display: { md: "block", xs: "none" } }}>
      <Paper elevation={2}>
        <Container maxWidth="lg" sx={{ display: "flex" }}>
          {NavigationLinksList}
          {/* APP Navigation */}
          <Link
            href={`/coupons-app`}
            style={{
              padding: "0 0.625rem",
              textDecoration: "none",
              color: "black",
              fontWeight: "400",
              fontSize: "0.85rem",
              letterSpacing: "2px",
            }}>
            <Tooltip
              title="Get Alcoupon App For Discounts & Deals"
              sx={{
                display: "flex",
                alignItems: "center",
                border: "1px solid #9B469D",
                padding:"0.2rem 0.5rem",
                borderRadius:"5px",
                margin:"0.3rem 0",
              }}>
              <Box>
                Alcoupon App
                <AndroidIcon sx={{ margin: "0 0.5rem" }} />
                <AppleIcon />
              </Box>
            </Tooltip>
          </Link>

          {/* APP Navigation */}
        </Container>
      </Paper>
    </Box>
  );
}
export default NavigationLinks;
